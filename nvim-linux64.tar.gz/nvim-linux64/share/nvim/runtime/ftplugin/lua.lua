-- use treesitter over syntax
vim.treesitter.start()
