-- Neovim syntax file
-- Language:	Treesitter query
-- Last Change:	2022 Apr 13

-- it's a lisp!
vim.cmd([[ runtime! syntax/lisp.vim ]])
